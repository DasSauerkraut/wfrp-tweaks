# WFRP - Tweaks
Adds a host of small tweaks as well as macro support for spells and prayers.
## Links:
* Manifest: https://raw.githubusercontent.com/DasSauerkraut/wfrp-tweaks/master/module.json
* Direct Link: https://github.com/DasSauerkraut/wfrp-gwmwg/raw/master/package/wfrp-gwmwg-v1.0.0.zip

